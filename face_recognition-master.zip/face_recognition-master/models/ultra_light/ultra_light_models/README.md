Download the ultra light model from the [link here](https://drive.google.com/drive/folders/1EDOJtWE_rnotlHZBRoYvPotRHr9PghxY?usp=sharing)
